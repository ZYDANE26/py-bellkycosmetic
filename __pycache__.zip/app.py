from flask import Flask
from rutas.categoria import categoria_bp
from rutas.producto import producto_bp

from flask_cors import CORS


#INICIAR LA APLICACION

app = Flask(__name__)
CORS(app)

app.register_blueprint(categoria_bp)
app.register_blueprint(producto_bp)


#INICIAR LA APLICACION
if __name__ == '__main__':
  app.run(debug=True)